﻿namespace WindowsDogwalker
{
    partial class frmAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtDay = new System.Windows.Forms.DateTimePicker();
            this.cboCustName = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb1hour = new System.Windows.Forms.RadioButton();
            this.rb30Minutes = new System.Windows.Forms.RadioButton();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbWalk = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCustNotes = new System.Windows.Forms.TextBox();
            this.cbotime = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtDay
            // 
            this.dtDay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDay.Location = new System.Drawing.Point(35, 31);
            this.dtDay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtDay.Name = "dtDay";
            this.dtDay.Size = new System.Drawing.Size(103, 20);
            this.dtDay.TabIndex = 1;
            // 
            // cboCustName
            // 
            this.cboCustName.FormattingEnabled = true;
            this.cboCustName.Location = new System.Drawing.Point(35, 115);
            this.cboCustName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboCustName.Name = "cboCustName";
            this.cboCustName.Size = new System.Drawing.Size(141, 21);
            this.cboCustName.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 52);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 100);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Customer";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rb1hour);
            this.groupBox1.Controls.Add(this.rb30Minutes);
            this.groupBox1.Location = new System.Drawing.Point(175, 31);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(125, 63);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Duration";
            // 
            // rb1hour
            // 
            this.rb1hour.AutoSize = true;
            this.rb1hour.Location = new System.Drawing.Point(11, 36);
            this.rb1hour.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rb1hour.Name = "rb1hour";
            this.rb1hour.Size = new System.Drawing.Size(57, 17);
            this.rb1hour.TabIndex = 1;
            this.rb1hour.TabStop = true;
            this.rb1hour.Text = "1 Hour";
            this.rb1hour.UseVisualStyleBackColor = true;
            // 
            // rb30Minutes
            // 
            this.rb30Minutes.AutoSize = true;
            this.rb30Minutes.Location = new System.Drawing.Point(11, 16);
            this.rb30Minutes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rb30Minutes.Name = "rb30Minutes";
            this.rb30Minutes.Size = new System.Drawing.Size(77, 17);
            this.rb30Minutes.TabIndex = 0;
            this.rb30Minutes.TabStop = true;
            this.rb30Minutes.Text = "30 Minutes";
            this.rb30Minutes.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(43, 261);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(93, 26);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(289, 261);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 27);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbWalk
            // 
            this.cbWalk.FormattingEnabled = true;
            this.cbWalk.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.cbWalk.Location = new System.Drawing.Point(193, 115);
            this.cbWalk.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbWalk.Name = "cbWalk";
            this.cbWalk.Size = new System.Drawing.Size(64, 21);
            this.cbWalk.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(191, 100);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Walk";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(279, 100);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Play";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.comboBox2.Location = new System.Drawing.Point(282, 115);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(64, 21);
            this.comboBox2.TabIndex = 13;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(41, 154);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Customer Notes";
            // 
            // txtCustNotes
            // 
            this.txtCustNotes.Location = new System.Drawing.Point(43, 169);
            this.txtCustNotes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtCustNotes.Multiline = true;
            this.txtCustNotes.Name = "txtCustNotes";
            this.txtCustNotes.Size = new System.Drawing.Size(330, 64);
            this.txtCustNotes.TabIndex = 15;
            // 
            // cbotime
            // 
            this.cbotime.FormattingEnabled = true;
            this.cbotime.Items.AddRange(new object[] {
            "8:00",
            "8:30",
            "9:00",
            "9:30",
            "10:00",
            "10:30",
            "11:00",
            "11:30",
            "1:00",
            "1:30",
            "2:00",
            "2:30",
            "3:00",
            "3:30",
            "4:00",
            "4:30",
            "5:00"});
            this.cbotime.Location = new System.Drawing.Point(35, 68);
            this.cbotime.Name = "cbotime";
            this.cbotime.Size = new System.Drawing.Size(103, 21);
            this.cbotime.TabIndex = 18;
            // 
            // frmAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 322);
            this.Controls.Add(this.cbotime);
            this.Controls.Add(this.txtCustNotes);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbWalk);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cboCustName);
            this.Controls.Add(this.dtDay);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAppointment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "New Appointment";
            this.Load += new System.EventHandler(this.frmAppointment_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dtDay;
        private System.Windows.Forms.ComboBox cboCustName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rb1hour;
        private System.Windows.Forms.RadioButton rb30Minutes;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbWalk;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCustNotes;
        private System.Windows.Forms.ComboBox cbotime;
    }
}