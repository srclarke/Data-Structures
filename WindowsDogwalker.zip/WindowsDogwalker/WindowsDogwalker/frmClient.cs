﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsDogwalker
{
    public partial class frmClient : Form
    {
        public frmClient()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult cancel = new DialogResult();
            cancel = MessageBox.Show("Are you sure?", "?", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (cancel == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string sqlText = "SELECT MAX(customerName) FROM Customer";

            SqlDataAdapter insertrec = new SqlDataAdapter("select * from emp", Properties.Settings.Default.Connection);
            //SqlConnection sqlConn = new SqlConnection(@"Data Source=LAPTOP-66NST80S;Initial Catalog=Dogwalker;Integrated Security=True");
            SqlConnection sqlConn = new SqlConnection(@"Data Source=LAPTOP-3FF0K7D8;Initial Catalog=Dogwalker;Integrated Security=True");
            SqlCommand command = new SqlCommand(sqlText, sqlConn);

            SqlDataAdapter inrec = new SqlDataAdapter();
            inrec.InsertCommand = new SqlCommand("INSERT INTO Customer VALUES(@Pup_Name,@CustFirstName,@CustLastName,@Cust_Address,@Cust_City,@Cust_State,@Cust_zip,@Cust_Phone,@Cust_email,@Notes)", sqlConn);
            inrec.InsertCommand.Parameters.Add("@Pup_Name", SqlDbType.VarChar).Value = txtPupName.Text ;
            inrec.InsertCommand.Parameters.Add("@CustFirstName", SqlDbType.VarChar).Value = txtFirstName.Text;
            inrec.InsertCommand.Parameters.Add("@CustLastName", SqlDbType.VarChar).Value = txtLastName.Text;
            inrec.InsertCommand.Parameters.Add("@Cust_Address", SqlDbType.VarChar).Value = txtAddress.Text;
            inrec.InsertCommand.Parameters.Add("@Cust_City", SqlDbType.VarChar).Value = txtCity.Text;
            inrec.InsertCommand.Parameters.Add("@Cust_State", SqlDbType.VarChar).Value = cboState.SelectedItem.ToString();
            inrec.InsertCommand.Parameters.Add("@Cust_zip", SqlDbType.VarChar).Value = txtZip.Text;
            inrec.InsertCommand.Parameters.Add("@Cust_Phone", SqlDbType.VarChar).Value = txtPhone.Text;
            inrec.InsertCommand.Parameters.Add("@Cust_email", SqlDbType.VarChar).Value = txtEmail.Text;
            inrec.InsertCommand.Parameters.Add("@Notes", SqlDbType.VarChar).Value = txtNotes.Text;


            sqlConn.Open();
            inrec.InsertCommand.ExecuteNonQuery();
            sqlConn.Close();
            MessageBox.Show("Client Successfully added");
            this.Close();
        }

        private void frmClient_Load(object sender, EventArgs e)
        {

        }
    }
}
