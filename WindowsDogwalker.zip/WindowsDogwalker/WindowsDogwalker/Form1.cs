﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;


namespace WindowsDogwalker
{

    public partial class Form1 : Form
    {
        public object ConfigurationManager { get; private set; }

        public static Hashtable convertDataTableToHashTable(DataTable dtIn, string keyField, string valueField)
        {
            Hashtable htOut = new Hashtable();
            foreach (DataRow drIn in dtIn.Rows)
            {
                htOut.Add(drIn[keyField].ToString(), drIn[valueField].ToString());
            }
            return htOut;
        }

        public Form1()
        {
            InitializeComponent();
        }

       
        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void btnClients_Click(object sender, EventArgs e)
        {
            frmClient newformClient = new frmClient();
            newformClient.Show();
        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            frmAppointment newformAppointment = new frmAppointment();
            newformAppointment.Show();

        }

        
        private void Form1_Load_1(object sender, EventArgs e)
        {
             
            // hash table for tool tip display of customer address.

            var s = "select CustFirstName + ' ' + CustLastName as keyfield, Cust_Address + ' ' + Cust_City as address from customer a join Appointment b on a.CustFirstName +' '+a.CustLastName = b.Cust_name";
            var conn = new SqlConnection(@"Data Source=LAPTOP-3FF0K7D8;Initial Catalog=Dogwalker;Integrated Security=True");
            //var c = new SqlConnection(yourConnectionString); // Your Connection String here
            var addressAdapter = new SqlDataAdapter(s, conn);

            var comBuilder = new SqlCommandBuilder(addressAdapter);
            var dt = new DataTable();
            addressAdapter.Fill(dt);
         

            Hashtable sendData = new Hashtable();
            //You need to pass datatable, key field and value field
            sendData = convertDataTableToHashTable(dt, "keyfield", "address");



            var select = "select b.Appointment_Date as Date,b.Appointment_Time as Time, CustFirstName + ' ' + CustLastName as [Customer Name] from customer a join Appointment b on a.CustFirstName +' '+a.CustLastName = b.Cust_name";
            var c = new SqlConnection(@"Data Source=LAPTOP-3FF0K7D8;Initial Catalog=Dogwalker;Integrated Security=True");
            //var c = new SqlConnection(yourConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

          //  MessageBox.Show(" " +  + " ");
        }
    }
}
