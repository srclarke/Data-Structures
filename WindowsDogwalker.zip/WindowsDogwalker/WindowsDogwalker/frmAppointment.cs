﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsDogwalker
{
    public partial class frmAppointment : Form
    {
        public frmAppointment()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult cancel = new DialogResult();
            cancel = MessageBox.Show("Are you sure?", "?", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (cancel == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void frmAppointment_Load(object sender, EventArgs e)
        {

            SqlDataAdapter da = new SqlDataAdapter("select custfirstname + ' ' + custlastname as name from customer", Properties.Settings.Default.Connection);

            DataSet ds = new DataSet();
            da.Fill(ds);

            cboCustName.DataSource = ds.Tables[0];
            cboCustName.ValueMember = "Name";
            cboCustName.SelectedIndex = -1;
            da.Dispose();

          }

        private void btnSave_Click(object sender, EventArgs e)
        { 
            string sqlText = "SELECT MAX(customerName) FROM Customer";

            SqlDataAdapter insertrec = new SqlDataAdapter("select * from emp", Properties.Settings.Default.Connection);
            //SqlConnection sqlConn = new SqlConnection(@"Data Source=LAPTOP-66NST80S;Initial Catalog=Dogwalker;Integrated Security=True");
            SqlConnection sqlConn = new SqlConnection(@"Data Source=LAPTOP-3FF0K7D8;Initial Catalog=Dogwalker;Integrated Security=True");
            SqlCommand command = new SqlCommand(sqlText, sqlConn);
            string durration = null;

            if (rb1hour.Checked == true) {
                durration = "1 hour"; 
            }else
            {
                durration = "30 Minutes";
            }


            SqlDataAdapter inrec = new SqlDataAdapter();
            inrec.InsertCommand = new SqlCommand("INSERT INTO Appointment VALUES(@cust_Name,@Appointment_Date,@Appointment_Time,@Appointment_walk,@Appointment_Play,@Appointment_Message,@Appointment_durration)", sqlConn);
            inrec.InsertCommand.Parameters.Add("@cust_Name", SqlDbType.VarChar).Value = cboCustName.SelectedValue;
            inrec.InsertCommand.Parameters.Add("@Appointment_Date", SqlDbType.VarChar).Value = dtDay.Text;
            inrec.InsertCommand.Parameters.Add("@Appointment_Time", SqlDbType.VarChar).Value = cbotime.SelectedItem.ToString();
            inrec.InsertCommand.Parameters.Add("@Appointment_walk", SqlDbType.VarChar).Value = cbWalk.SelectedItem.ToString();
            inrec.InsertCommand.Parameters.Add("@Appointment_Play", SqlDbType.VarChar).Value = comboBox2.SelectedItem.ToString();
            inrec.InsertCommand.Parameters.Add("@Appointment_Message", SqlDbType.VarChar).Value = txtCustNotes.Text;
            inrec.InsertCommand.Parameters.Add("@Appointment_durration", SqlDbType.VarChar).Value = durration;

            sqlConn.Open();
            inrec.InsertCommand.ExecuteNonQuery();
            sqlConn.Close();
            MessageBox.Show("Appointment added");
            this.Close();
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbWalk.SelectedItem.ToString() == "Y" && comboBox2.SelectedItem.ToString() == "Y")
            {
                rb1hour.Checked = true;
            }
        }
    }
}
